# Controles complementares de duração

Executar `python executar_controles.py`. Requer Python, NumPy e pandas. Os dois módulos em src são cópias sem alteração do repositório publicado no commit adfcaf730c47e0b035a240b3ac73605448ff1e96.

Foram avaliadas 84 séries artificiais independentes de 300 posições em grade de dez minutos. O fundo é uma rampa de 100 com incremento de 0,2 por posição, evitando persistência. Cada série tem um único intervalo controlado iniciado na posição 100: NaN para Lacuna, valor 10 para stuck não nulo e zero para stuck-at-zero. Durações de 1 a 12 posições para Lacuna e de 1 a 36 para cada persistência. Limiares originais: 6, 24 e 24 posições. Nenhuma nova seleção de limiares, nenhum retreinamento e nenhuma alteração dos resultados anteriores.

Resultado: 51 sequências abaixo do mínimo não foram identificadas; 33 com duração no mínimo ou acima foram identificadas com limites exatos. Isso verifica a implementação da fronteira de duração e não constitui validação independente com falhas físicas. Não foram avaliados aqui ruído, valores quase constantes, legitimidade ambiental de zeros ou sensibilidade à variação dos próprios limiares. Estes controles não são parte dos 60 eventos artificiais da avaliação anterior e não devem ser somados a eles.
