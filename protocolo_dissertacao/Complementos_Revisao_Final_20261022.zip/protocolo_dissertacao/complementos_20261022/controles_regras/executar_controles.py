"""Controles de duração das regras publicadas, sem alterar os limiares."""
from pathlib import Path
import sys,csv
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from regras_deterministicas import detectar_falha
rows=[]
for fault,minimum,max_length in [('lacuna',6,12),('stuck',24,36),('stuck_at_zero',24,36)]:
    for length in range(1,max_length+1):
        b=pd.DataFrame({'Datetime':pd.date_range('2023-01-01',periods=300,freq='10min'),'valor':100+np.arange(300,dtype=float)*.2})
        begin,end=100,100+length-1
        b.loc[begin:end,'valor']=np.nan if fault=='lacuna' else (10. if fault=='stuck' else 0.)
        events=detectar_falha(b,'valor',fault)
        expected=int(length>=minimum)
        correct=len(events)==expected
        if expected and len(events)==1:correct=correct and events[0]['inicio_idx']==begin and events[0]['fim_idx']==end
        rows.append(dict(falha=fault,minimo_regra=minimum,duracao_pts=length,eventos_esperados=expected,eventos_identificados=len(events),intervalo_correto=correct))
with (ROOT/'resultados_controles.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert all(r['intervalo_correto'] for r in rows)
print(f'{len(rows)} controles concluídos: {sum(r["eventos_esperados"]==0 for r in rows)} abaixo do mínimo e {sum(r["eventos_esperados"]==1 for r in rows)} no mínimo ou acima.')
