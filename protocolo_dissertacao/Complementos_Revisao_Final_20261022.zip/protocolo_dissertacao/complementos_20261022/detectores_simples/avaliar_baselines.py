import json
from pathlib import Path
import numpy as np
import argparse
p=argparse.ArgumentParser()
p.add_argument('--raiz',type=Path,default=Path(__file__).resolve().parent/'dados_cache')
p.add_argument('--saida',type=Path,default=Path(__file__).resolve().parent/'resultados_recalculados.json')
args=p.parse_args()
ROOT=args.raiz

def starts(n,j,a):
 x=list(range(0,n-j+1,a))
 if x[-1]!=n-j:x.append(n-j)
 return np.array(x)
def score(z,f):
 names=z['features'].tolist()
 if f=='oscilacao':return z['X'][:,names.index('std')]
 ids=[i for i,s in enumerate(names) if s.startswith('lag_')]
 return np.maximum(0,-np.diff(z['X'][:,ids],axis=1).min(axis=1))
def metric(y,p):
 tp=int((y&p).sum());fp=int((~y&p).sum());fn=int((y&~p).sum());tn=int((~y&~p).sum())
 return dict(tp=tp,fp=fp,fn=fn,tn=tn,f1=2*tp/max(1,2*tp+fp+fn),precision=tp/max(1,tp+fp),recall=tp/max(1,tp+fn))
out=[]
for var in ['PM25','PM10','Temperatura','Umidade']:
 folder=ROOT/var/'cache'
 for fault in ['oscilacao','queda']:
  candidates=[]
  for j in range(20,101,10):
   zz={p:[dict(np.load(folder/f'{p}_{r}_{j}.npz',allow_pickle=False)) for r in range(1,6)] for p in ['treino','validacao']}
   vs=[score(z,fault) for z in zz['validacao']]
   for a in range(5,j+1,5):
    vv=[];eligible=True
    for k in range(5):
     for part in ['treino','validacao']:
      z=zz[part][k];ix=np.searchsorted(z['starts'],starts(int(z['n']),j,a));assert np.array_equal(z['starts'][ix],starts(int(z['n']),j,a))
      y=z['y_'+fault][ix].astype(bool)
      if min(int(y.sum()),int((~y).sum()))<(2 if part=='treino' else 1):eligible=False
      if part=='validacao':vv.append((vs[k][ix],y))
    if not eligible:continue
    thresholds=np.unique(np.r_[np.quantile(np.concatenate([s for s,y in vv]),np.linspace(0,1,101)),np.inf])
    f1=[]
    for s,y in vv:
     p=s[:,None]>=thresholds[None,:];tp=(p&y[:,None]).sum(axis=0);fp=(p&~y[:,None]).sum(axis=0);fn=(~p&y[:,None]).sum(axis=0)
     f1.append(np.divide(2*tp,2*tp+fp+fn,out=np.zeros(len(thresholds)),where=(2*tp+fp+fn)!=0))
    means=np.mean(f1,axis=0);sd=np.std(f1,axis=0,ddof=1)
    best=sorted(range(len(thresholds)),key=lambda i:(-means[i],sd[i],-thresholds[i]))[0]
    candidates.append(dict(janela=j,avanco=a,limiar=float(thresholds[best]),f1_val=float(means[best]),dp_val=float(sd[best])))
  c=sorted(candidates,key=lambda c:(-c['f1_val'],c['dp_val'],c['janela'],c['avanco'],-c['limiar']))[0]
  rr=[]
  for r in range(1,6):
   z=dict(np.load(folder/f"teste_{r}_{c['janela']}.npz",allow_pickle=False));requested=starts(int(z['n']),c['janela'],c['avanco']);ix=np.searchsorted(z['starts'],requested);assert np.array_equal(z['starts'][ix],requested)
   s=score(z,fault)[ix];y=z['y_'+fault][ix].astype(bool);p=s>=c['limiar'];rr.append(dict(rodada=r,n=len(y),positivas=int(y.sum()),f1_ref=2*int(y.sum())/(len(y)+int(y.sum())),**metric(y,p)))
  row=dict(variavel=var,falha=fault,**c,f1_teste=float(np.mean([x['f1'] for x in rr])),dp_teste=float(np.std([x['f1'] for x in rr],ddof=1)),f1_ref=float(np.mean([x['f1_ref'] for x in rr])),rodadas=rr)
  out.append(row);print(json.dumps({k:v for k,v in row.items() if k!='rodadas'}),flush=True)
args.saida.write_text(json.dumps(out,indent=2))
