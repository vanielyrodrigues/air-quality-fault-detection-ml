# Comparação complementar com detectores simples

Análise adicionada após o conhecimento dos resultados anteriores; não constitui teste independente novo. Nenhum classificador foi retreinado ou alterado. Não foi alterado o repositório público.

Oscilação: sinalizar se o desvio-padrão populacional dos valores preparados da janela for maior ou igual ao limiar. Queda: sinalizar se a maior redução entre duas leituras consecutivas da janela, limitada inferiormente a zero, for maior ou igual ao limiar.

Seleção: mesmos 108 pares de janela e avanço (J=20..100 de 10 em 10; A=5..J de 5 em 5), incluindo janela final adicional. Elegibilidade: treino com pelo menos duas janelas por classe e validação com ambas as classes em cada uma das cinco rodadas. Para cada par, os candidatos ao limiar são os 101 quantis de 0 a 100% dos escores reunidos exclusivamente nas cinco validações, removidas duplicatas, mais infinito para a saída sempre negativa. O mínimo inclui a saída sempre positiva. Escolha por maior F1 médio na validação; desempate por menor DP amostral, menor J, menor A e maior limiar. Um único limiar e par J/A por variável e tarefa, mantidos nas cinco rodadas de teste.

A seleção dos detectores já foi concluída; não ajustar suas fórmulas, candidatos ou limiares com base nos resultados do teste. As janelas e prevalências selecionadas podem diferir das dos classificadores, impedindo atribuir diferenças exclusivamente ao algoritmo. A referência de todas positivas é calculada nas mesmas janelas de cada detector. Cobertura temporal e dados simulados são os mesmos dos experimentos arquivados. O teste sem injeção não foi avaliado neste complemento.

Execução: extrair o ZIP e executar `python avaliar_baselines.py`. Requer Python 3.12 e NumPy (a análise foi executada com as versões registradas em ambiente.json). O pacote contém os caches de atributos e rótulos necessários. A saída padrão é resultados_recalculados.json. Os hashes identificam os caches locais arquivados; eles não são prova independente de correspondência com todos os arquivos do GitHub. A base consolidada de entrada já foi conferida com o SHA-256 publicado.

Conferência independente da seleção final: TP, FP e FN das 40 avaliações foram recalculados diretamente nas bases por rodada, extraindo os valores das janelas e aplicando as duas fórmulas, e coincidiram com os resultados baseados nos caches.
