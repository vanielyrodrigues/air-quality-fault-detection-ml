# MCC complementar

Métrica acrescentada após as análises anteriores. Não foi usada para escolher modelos, janelas, avanços ou limiares. Não houve retreinamento. A avaliação usa os rótulos simulados do cenário com injeção, não diagnósticos físicos independentes.

Executar `python calcular_mcc.py` após extrair o pacote. O script usa apenas a biblioteca padrão do Python. As médias e o desvio-padrão amostral são calculados sobre cinco MCC por rodada, sem agregar as matrizes previamente. Se o denominador da expressão do MCC for zero, o resultado é definido como zero, seguindo a convenção de implementação do scikit-learn. A sinalização de todas as janelas tem MCC zero nessa convenção.

São 160 avaliações dos classificadores (32 configurações, cinco rodadas) e 40 dos detectores simples (oito configurações, cinco rodadas). Todos os 200 resultados foram confrontados com sklearn.metrics.matthews_corrcoef e coincidiram com tolerância de 1e-12.

Os CSV de entrada correspondem aos resultados finais arquivados. Umidade foi recuperada do repositório no commit adfcaf730c47e0b035a240b3ac73605448ff1e96; os demais foram lidos dos resultados locais da revisão de 20/10. As contagens dos detectores simples vêm da comparação complementar já entregue. Os hashes identificam os arquivos incluídos. Nada foi publicado automaticamente no GitHub.

Referência da definição: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.matthews_corrcoef.html (consulta em 22/10/2026).
