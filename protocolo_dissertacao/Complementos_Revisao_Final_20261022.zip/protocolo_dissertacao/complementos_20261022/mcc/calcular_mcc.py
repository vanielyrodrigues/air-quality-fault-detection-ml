"""MCC complementar calculado das contagens já arquivadas, sem nova seleção."""
from pathlib import Path
import csv,json,math,statistics
from collections import defaultdict
ROOT=Path(__file__).resolve().parent

def mcc(tp,tn,fp,fn):
    den=math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    return (tp*tn-fp*fn)/den if den else 0.0
rows=[]
for var in ['PM25','PM10','Temperatura','Umidade']:
    with (ROOT/'entradas'/f'{var}.csv').open() as f:
        for r in csv.DictReader(f):
            if r['cenario']!='com_injecao':continue
            counts={k:int(float(r[k])) for k in ['tp','tn','fp','fn']}
            rows.append(dict(grupo='classificador',variavel=var,falha=r['falha'],modelo=r['modelo'],rodada=int(r['rodada']),**counts,mcc=mcc(**counts)))
for c in json.loads((ROOT/'entradas'/'detectores_simples.json').read_text()):
    for r in c['rodadas']:
        counts={k:r[k] for k in ['tp','tn','fp','fn']}
        rows.append(dict(grupo='detector_simples',variavel=c['variavel'],falha=c['falha'],modelo='desvio_padrao' if c['falha']=='oscilacao' else 'maior_reducao',rodada=r['rodada'],**counts,mcc=mcc(**counts)))
with (ROOT/'mcc_por_rodada.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
groups=defaultdict(list)
for r in rows:groups[r['grupo'],r['variavel'],r['falha'],r['modelo']].append(r['mcc'])
summary=[]
for (g,v,f,m),vals in sorted(groups.items()):
    assert len(vals)==5
    summary.append(dict(grupo=g,variavel=v,falha=f,modelo=m,mcc_medio=statistics.mean(vals),dp_mcc=statistics.stdev(vals)))
with (ROOT/'mcc_resumo.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
print(f'Concluídas {len(rows)} avaliações e {len(summary)} resumos de cinco rodadas.')
