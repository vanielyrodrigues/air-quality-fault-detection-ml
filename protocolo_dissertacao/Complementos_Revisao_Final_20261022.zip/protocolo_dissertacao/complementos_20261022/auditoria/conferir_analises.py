"""Conferências complementares sem alterar ou retreinar os classificadores."""
from pathlib import Path
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parent
IN=ROOT/'entradas'
OUT=ROOT/'resultados'
OUT.mkdir(exist_ok=True)
COLS={'PM25':'MP2,5_1','PM10':'MP10_1','Temperatura':'Temperatura','Umidade':'Umidade'}

def starts(n,j,a):
    result=list(range(0,n-j+1,a)) if n>=j else []
    if result and result[-1]!=n-j:result.append(n-j)
    return result

def intervals(mask):
    changes=mask.ne(mask.shift()).cumsum()
    return [v for _,v in mask[mask].groupby(changes[mask])]

raw=pd.read_csv(IN/'dados_ordenados.csv',parse_dates=['Datetime']).sort_values('Datetime')
raw=raw[raw.Datetime.between('2023-10-07','2023-11-09')]
grade=pd.date_range(raw.Datetime.min().floor('10min'),raw.Datetime.max().floor('10min'),freq='10min')
c1,c2=grade[int(len(grade)*.6)],grade[int(len(grade)*.8)]
parts={'treino':raw[raw.Datetime<c1], 'validacao':raw[(raw.Datetime>=c1)&(raw.Datetime<c2)],'teste':raw[raw.Datetime>=c2]}
missing=[];gaps=[];prepared={}
for part,sub in parts.items():
    b=sub.set_index('Datetime')[list(COLS.values())].resample('10min').mean();prepared[part]=b
    for var,col in COLS.items():
        mask=b[col].isna();seq=intervals(mask)
        missing.append(dict(variavel=var,particao=part,posicoes=len(b),ausentes=int(mask.sum()),percentual=100*mask.mean(),maior_sequencia=max(map(len,seq),default=0)))
        for v in seq:
            if len(v)>=6:gaps.append(dict(variavel=var,particao=part,inicio=v.index[0],fim=v.index[-1],posicoes=len(v)))
pd.DataFrame(missing).to_csv(OUT/'ausencias_por_particao.csv',index=False)
pd.DataFrame(gaps).to_csv(OUT/'lacunas_antes_interpolacao.csv',index=False)

cfg=pd.read_csv(IN/'configuracoes_classificadores.csv')
points=[];windows=[]
for var in COLS:
    for part in parts:
        for r in range(1,6):
            b=pd.read_csv(IN/var/'bases'/f'rodada_{r}'/f'{part}.csv')
            for fault in ['oscilacao','queda','lacuna']:
                count=int(b.label.eq(fault).sum())
                points.append(dict(variavel=var,particao=part,rodada=r,falha=fault,posicoes=len(b),positivas=count,percentual=100*count/len(b)))
            for _,c in cfg[cfg.variavel.eq(var)].iterrows():
                j,a=int(c.janela),int(c.avanco);ix=starts(len(b),j,a)
                positive=sum(b.iloc[s:s+j].label.eq(c.falha).any() for s in ix)
                windows.append(dict(variavel=var,particao=part,rodada=r,falha=c.falha,modelo=c.modelo,janela=j,avanco=a,janelas=len(ix),positivas=positive,percentual=100*positive/len(ix)))
pd.DataFrame(points).to_csv(OUT/'proporcao_pontos_por_rodada.csv',index=False)
pd.DataFrame(points).groupby(['variavel','falha','particao']).percentual.agg(['mean','min','max']).to_csv(OUT/'proporcao_pontos_resumo.csv')
pd.DataFrame(windows).to_csv(OUT/'proporcao_janelas_por_rodada.csv',index=False)
pd.DataFrame(windows).groupby(['variavel','falha','modelo','particao']).percentual.agg(['mean','min','max']).to_csv(OUT/'proporcao_janelas_resumo.csv')

patterns=pd.read_csv(IN/'padroes_preexistentes_base_v2.csv')
alerts=[]
for var,model in [('PM25','catboost'),('PM10','catboost'),('Temperatura','xgboost')]:
    for r in range(1,6):
        d=pd.read_csv(IN/var/'predicoes'/f'{model}_queda_{r}.csv');d=d[d.cenario.eq('sem_injecao')].copy()
        start=pd.to_datetime(d.Datetime_ini);end=pd.to_datetime(d.Datetime_fim)
        overlap=np.zeros(len(d),dtype=bool)
        for _,e in patterns[patterns.variavel.eq(COLS[var])].iterrows():
            overlap|=((start<=pd.Timestamp(e.fim))&(end>=pd.Timestamp(e.inicio))).to_numpy()
        p=d.predicao.eq(1).to_numpy();mask=prepared['teste'][COLS[var]].isna()
        touched=[bool(mask.loc[a:b].any()) for a,b in zip(start,end)]
        alerts.append(dict(variavel=var,modelo=model,rodada=r,janelas=len(d),alertas=int(p.sum()),sobreposicao_persistencia=int(overlap.sum()),alertas_sobre_persistencia=int((p&overlap).sum()),alertas_fora_persistencia=int((p&~overlap).sum()),janelas_com_interpolacao=sum(touched)))
# O XGBoost de Queda em Umidade usa J=100 e A=100 nas cinco rodadas.
# O mesmo período sem injeção é reutilizado; o indicador abaixo não depende das predições.
b=prepared['teste']['Umidade'];ix=starts(len(b),100,100)
pd.DataFrame([dict(variavel='Umidade',janela=100,avanco=100,janelas=len(ix),janelas_com_interpolacao=sum(bool(b.iloc[s:s+100].isna().any()) for s in ix))]).to_csv(OUT/'interpolacao_janelas_umidade.csv',index=False)
pd.DataFrame(alerts).to_csv(OUT/'cruzamento_alertas_persistencia_interpolacao.csv',index=False)
assert len(missing)==12
assert len(gaps)==16  # Quatro intervalos compartilhados pelas quatro variáveis.
assert all(x['ausentes']=={'treino':264,'validacao':184,'teste':70}[x['particao']] for x in missing)
print('Concluídas conferências de ausências, pontos, janelas e alertas. Nenhum modelo foi ajustado.')
