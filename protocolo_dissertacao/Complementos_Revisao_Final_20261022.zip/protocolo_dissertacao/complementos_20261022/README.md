# Complementos da revisão de 22/10/2026

Material suplementar às análises da dissertação de Vaniely Rodrigues da Cruz. Não substitui nem altera os resultados do protocolo temporal anteriormente publicado. Os complementos foram acrescentados após o conhecimento dos resultados do teste; não constituem avaliação com novo conjunto independente.

## Conteúdo

- `detectores_simples/`: código, caches de atributos/rótulos, configurações selecionadas na validação e resultados dos detectores de desvio-padrão e maior redução entre leituras. Sem retreinamento dos quatro classificadores.
- `mcc/`: código e contagens para calcular o MCC de 32 configurações dos classificadores e oito detectores simples, em cinco rodadas. Média e desvio-padrão amostral por configuração; sem seleção pelo MCC.
- `controles_regras/`: 84 controles de duração com os módulos das regras publicados no commit adfcaf730c47e0b035a240b3ac73605448ff1e96. Sequências abaixo do mínimo, no limite e acima. Os 51 controles negativos e 33 positivos não são somados aos 60 eventos do experimento anterior.
- `auditoria/`: base consolidada, bases por partição e rodada, registros de injeção e predições necessárias às conferências complementares. O script reproduz as ausências anteriores à interpolação, as proporções de pontos e janelas por partição e os cruzamentos de alertas com persistência e preenchimento.
- `figura4/`: imagem substituta com o mesmo nome utilizado no Overleaf, CSV da série antes da interpolação, programa gerador e identificação da base. Apresenta o período experimental de outubro a novembro de 2023; substitui a ilustração anterior de período mais amplo.

## Execução

Após instalar as versões de `requirements_complementos.txt`, executar a partir desta pasta:

```bash
python detectores_simples/avaliar_baselines.py
python mcc/calcular_mcc.py
python controles_regras/executar_controles.py
python auditoria/conferir_analises.py
python figura4/gerar_figura4.py
```

Esses comandos não executam novo treinamento de Random Forest, XGBoost, CatBoost ou MLP. O programa dos detectores simples faz sua seleção na validação e utiliza os caches já arquivados; não deve ser adaptado em função dos resultados do teste.

## Interpretação

Os resultados usam rótulos simulados. Alertas sobre dados sem injeção adicional não comprovam defeitos físicos. Os quatro intervalos de ausências antes da interpolação são compartilhados pelas quatro variáveis e não correspondem a 16 interrupções independentes. As posições sem medição incluem ausências na grade temporal reamostrada e não permitem identificar uma causa de aquisição, comunicação ou armazenamento.

A referência de todas positivas usa as mesmas janelas de cada configuração. A frequência de pontos e de janelas positivas é diferente. Os cinco cenários compartilham os mesmos períodos físicos. Os limiares das regras, a ponderação de classes dos classificadores e suas demais configurações originais não foram alterados.

Os arquivos em `auditoria/entradas/*/bases` são as séries preparadas com injeção e seus registros por rodada; não são medições brutas. A base de entrada consolidada fica em `auditoria/entradas/dados_ordenados.csv`, com hash SHA-256 831b70f0f337538e9b175c22591a9e7742d8cc4382e04297ddc099b7630d17dc, correspondente ao registro publicado no protocolo original. Ela não substitui os arquivos individuais originais de aquisição.

## Correspondência com o repositório

O protocolo original foi consultado no commit adfcaf730c47e0b035a240b3ac73605448ff1e96. Este diretório ainda requer publicação em um novo commit. O identificador desse novo commit deverá ser registrado no apêndice após a publicação e a conferência. O código novo não está contido no commit antigo. O envio deste pacote não publica arquivos automaticamente.

## Conferências realizadas

- Contagens dos 40 testes dos detectores simples recalculadas diretamente nas bases, coincidindo com os caches.
- Os 200 MCC conferidos contra sklearn.metrics.matthews_corrcoef com tolerância de 1e-12.
- Os 84 controles de duração identificaram exatamente as condições programadas.
- Conferência de ausências: 264/184/70 posições por variável em treino/validação/teste, e quatro intervalos com pelo menos seis posições antes do preenchimento.
- A figura foi inspecionada visualmente. Não foi realizada nova validação independente com falhas físicas.
