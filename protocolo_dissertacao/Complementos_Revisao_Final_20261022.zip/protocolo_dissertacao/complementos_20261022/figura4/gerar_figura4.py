from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
ROOT=Path(__file__).resolve().parent
s=pd.read_csv(ROOT/'serie_pm25_antes_interpolacao.csv',parse_dates=['Datetime'])
fig,ax=plt.subplots(figsize=(10.5,3.8))
ax.plot(s.Datetime,s.PM25,color='#0072B2',linewidth=.9,label='Série sem injeção')
ax.set_ylabel(r'PM$_{2,5}$ ($\mu$g/m$^3$)',fontsize=11)
ax.set_xlabel('Data (2023)',fontsize=10)
ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.SA,interval=1))
ax.xaxis.set_major_formatter(mdates.DateFormatter('%d/%m'))
ax.set_xlim(pd.Timestamp('2023-10-07'),pd.Timestamp('2023-11-09'))
ax.grid(alpha=.23)
ax.tick_params(labelsize=9)
ax.legend(loc='upper right',fontsize=9,framealpha=.95)
fig.tight_layout()
fig.savefig(ROOT/'Figura_1_original_fig 04.png',dpi=300)
plt.close(fig)
